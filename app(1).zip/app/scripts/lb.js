// JavaScript Document

    $(".slider").yxMobileSlider({width:640,height:320,during:3000})